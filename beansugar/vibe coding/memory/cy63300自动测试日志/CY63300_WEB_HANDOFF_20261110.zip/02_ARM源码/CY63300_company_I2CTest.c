/**
  ******************************************************************************
  * @FileName   : CY63300.c
  * @Version    : v1.0
  * @Author     : FZM
  * @Date       : 2025-5-6
  * @Brief      : CY63300 测试用例
  *
  ******************************************************************************
  */
#include "CY63300.h"

void HardFault_Handler(void)
{
	while(1)
	{
		__nop();
	}
}

RES_t TestInit(void)
{
	Delay_init();
	SystemCoreClock = 21500000;
	M0_SYSCTRL->SYSCTRL0 = 0;
	M0_SYSCTRL->SYSCTRL1 = 0;
	M0_SYSCTRL->HSI_CTRL = 0;
	M0_SYSCTRL->PCLK_EN = 0;
	
    PeriCLK_Cmd(GPIO_PCLK | UART_PCLK, ENABLE);	
    GPIO_AlternateFunction(GPIOA, GPIO_Pin_0 | GPIO_Pin_1, 2, GPIO_Digital);
    UART_Init(UART0, 115200);
	UART_Cmd(UART0, UART_TX_RX, ENABLE);
	UART_IntClr(UART0, UART_RX_INT);
    UART_IntInit(UART0, UART_RX_INT, 3, ENABLE);
	printf("********************TestInit********************\n");
//	printf("********************TestInit********************\n");
//	printf("********************TestInit********************\n");
//	printf("\ntest init 123456789 987654321 123456789 987654321 tini tset\r\n");
	uartRxNum = 0;
//	while(uartRxNum < 5);
//	printf("%s\n", uartRxBuf);
	return OK;
}

RES_t GpioTest(void)
{
	printf("--------------------GpioTest--------------------\n");
	PeriCLK_Cmd(GPIO_PCLK, ENABLE);
	GPIO_Init_b(GPIOA, GPIO_Pin_2 | GPIO_Pin_3, GPIO_Dir_OUT);
	GPIO_Init_b(GPIOB, GPIO_Pin_All, GPIO_Dir_OUT);
	GPIO_Init_b(GPIOC, GPIO_Pin_All, GPIO_Dir_OUT);
	
	GPIO_AlternateFunction(GPIOA, GPIO_Pin_2, 0, GPIO_Digital);
	GPIO_AlternateFunction(GPIOA, GPIO_Pin_3, 4, GPIO_Digital);
	GPIO_AlternateFunction(GPIOB, GPIO_Pin_All, 0, GPIO_Digital);
	GPIO_AlternateFunction(GPIOC, GPIO_Pin_All, 0, GPIO_Digital);
	
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	for(int i = 0 ; i < 5; i++)
	{
		for(int pin = 0; pin < 6; pin++)
		{
			GPIO_SetBits(GPIOA, 1 << pin);
			GPIO_SetBits(GPIOB, 1 << pin);
			GPIO_SetBits(GPIOC, 1 << pin);
		}
		Delay_ms(50);
		for(int pin = 0; pin < 6; pin++)
		{
			GPIO_ResetBits(GPIOA, 1 << pin);
			GPIO_ResetBits(GPIOB, 1 << pin);
			GPIO_ResetBits(GPIOC, 1 << pin);
		}
		Delay_ms(50);
	}
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK);
	for(int i = 0 ; i < 5; i++)
	{
		for(int pin = 0; pin < 6; pin++)
		{
			GPIO_SetBits(GPIOA, 1 << pin);
			GPIO_SetBits(GPIOB, 1 << pin);
			GPIO_SetBits(GPIOC, 1 << pin);
		}
		Delay_ms(50);
		for(int pin = 0; pin < 6; pin++)
		{
			GPIO_ResetBits(GPIOA, 1 << pin);
			GPIO_ResetBits(GPIOB, 1 << pin);
			GPIO_ResetBits(GPIOC, 1 << pin);
		}
		Delay_ms(50);
	}
	printf("++++++++++++++++++++GpioTest++++++++++++++++++++\n\n");
	return OK;
}

//const uint32_t userValue __attribute__((at(64 * 1024))) = 0x5555AAAA;
//__attribute__((section("SRAM_CODE"))) RES_t RemapTest(void)
//{
//	RES_t ret = OK;
//	uint32_t zero = 0;
//	uint32_t sp;
//	uint32_t remappedUserValue = 0;
//	
//	sp = *(uint32_t*)zero;
//	printf("--------------------RemapTest--------------------\n");
//	printf("Remap disable\n");
//	printf("sp        at 0x00000: %08X\n", sp);
//	printf("userValue at 0x20000: %08X\n", *(uint32_t*)(64 * 1024));
//	if(*(uint32_t*)(64 * 1024) != userValue)
//	{
//		ret = Error;
//		printf("Error: value at 0x20000: %08x, expected: %08x\n", *(uint32_t*)(64 * 1024), userValue);
//	}
//	
//	SYSCTRL->REMAP_EN = 1;
//	remappedUserValue = *(uint32_t*)zero;
//	SYSCTRL->REMAP_EN = 0;
//	printf("Remap enable\n");
//	printf("value     at 0x00000: %08x\n", remappedUserValue);
//	if(remappedUserValue != userValue)
//	{
//		ret = Error;
//		printf("Error: value at 0x00000: %08x, expected: %08x\n", *(uint32_t*)zero, userValue);
//	}
//	
//	SYSCTRL->REMAP_EN = 0;
//	printf("Remap disable\n");
//	printf("value     at 0x00000: %08x\n", *(uint32_t*)zero);
//	if(*(uint32_t*)zero != sp)
//	{
//		ret = Error;
//		printf("Error: value at 0x00000: %08x, expected: %08x\n", *(uint32_t*)zero, sp);
//	}
//	printf("value     at 0x20000: %08x\n", *(uint32_t*)(64 * 1024));
//	if(*(uint32_t*)(64 * 1024) != userValue)
//	{
//		ret = Error;
//		printf("Error: value at 0x20000: %08x, expected: %08x\n", *(uint32_t*)(64 * 1024), userValue);
//	}
//	
//	printf("++++++++++++++++++++RemapTest++++++++++++++++++++\n\n");
//	return ret;
//}

uint32_t dmaIsr;
void DMA_IRQHandler(void)
{
	dmaIsr = M0_DMA->ISR;
	
	if(dmaIsr & (1 << 26))	//HT7
	{
		M0_DMA->IFCR = 1 << 26;
		printf("DMA HT7\n");
	}
	if(dmaIsr & (1 << 25))	//TC7
	{
		M0_DMA->IFCR = 1 << 25;
		printf("DMA TC7\n");
	}
	if(dmaIsr & (1 << 22))	//HT6
	{
		M0_DMA->IFCR = 1 << 22;
		printf("DMA HT4\n");
	}
	if(dmaIsr & (1 << 21))	//TC6
	{
		M0_DMA->IFCR = 1 << 21;
		printf("DMA TC4\n");
	}
	if(dmaIsr & (1 << 18))	//HT5
	{
		M0_DMA->IFCR = 1 << 18;
		printf("DMA HT4\n");
	}
	if(dmaIsr & (1 << 17))	//TC5
	{
		M0_DMA->IFCR = 1 << 17;
		printf("DMA TC4\n");
	}
	if(dmaIsr & (1 << 14))	//HT4
	{
		M0_DMA->IFCR = 1 << 14;
		printf("DMA HT4\n");
	}
	if(dmaIsr & (1 << 13))	//TC4
	{
		M0_DMA->IFCR = 1 << 13;
		printf("DMA TC4\n");
	}
	if(dmaIsr & (1 << 10))	//HT3
	{
		M0_DMA->IFCR = 1 << 10;
		printf("DMA HT3\n");
	}
	if(dmaIsr & (1 << 9))	//TC3
	{
		M0_DMA->IFCR = 1 << 9;
		printf("DMA TC3\n");
	}
	if(dmaIsr & (1 << 6))	//HT2
	{
		M0_DMA->IFCR = 1 << 6;
		printf("DMA HT2\n");
	}
	if(dmaIsr & (1 << 5))	//TC2
	{
		M0_DMA->IFCR = 1 << 5;
		printf("DMA TC2\n");
	}
	if(dmaIsr & (1 << 2))	//HT1
	{
		M0_DMA->IFCR = 1 << 2;
		printf("DMA HT1\n");
	}
	if(dmaIsr & (1 << 1))	//TC1
	{
		M0_DMA->IFCR = 1 << 1;
		printf("DMA TC1\n");
	}
}

RES_t DmaTest(void)
{
	RES_t ret = OK;
	SPIM_InitTypedef SPIM_InitStructure;
	static uint8_t txbuf[100], rxbuf[100];
	static uint32_t txbuf32[100], rxbuf32[100];
	const uint32_t encryptedValue[5] = {0x8994fb27, 0x8df500af, 0x8db7193f, 0x89d6c2b7, 0x8db378b7};
	uint32_t userKey = 0x1A2B3C4D, value = 0x12345678, sigma = 0x3d5b8f9a;	//0x12345678->0x7881a8e7
	
	for(int i = 0; i < 10; i++)
	{
		for(int j = 0; j < 10; j++)
		{
			txbuf[i * 10 + j] = '0' - 0 + j;
		}
	}
	memset(rxbuf, 0, 100);
	printf("--------------------DmaTest--------------------\n");
	PeriCLK_Cmd(GPIO_PCLK | SPI0_PCLK | DMA_HCLK, ENABLE); /* 开GPIO时钟 */

	NVIC_SetPriority(DMA_IRQn, 3);
	NVIC_EnableIRQ(DMA_IRQn);
	//M->M
	M0_DMA->CHx[6].CNDTR = 100;
	M0_DMA->CHx[6].CPAR  = (uint32_t)&rxbuf;
	M0_DMA->CHx[6].CMAR  = (uint32_t)&txbuf;
	M0_DMA->CHx[6].CCR   = 0x40DE;
	M0_DMA->CHx[6].CCR   |= 1;
	while((dmaIsr & (1 << 25)) == 0);
	if(memcmp(txbuf, rxbuf, 100))
	{
		ret = Error;
		printf("Error: DMA M2M\n");
	}
	
	//P->M，M->P  SPI
    GPIO_AlternateFunction(GPIOB, GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5, 1,
                           GPIO_Digital);
    SPIM_InitStructure.CLK_Div   = 10; /* must be even. */
    SPIM_InitStructure.CPOL      = CPOL_H;
    SPIM_InitStructure.CPHA      = CPHA_2ndedge;
    SPIM_InitStructure.NSS_TOG   = NSS_TOG_until_Stop;
    SPIM_InitStructure.TMODE     = TMOD_TR;
    SPIM_InitStructure.DATA_SIZE = BIT_8;
    SPI_Master_Init(SPI0, &SPIM_InitStructure);
    SPI_Cmd(SPI0, ENABLE);
	SPI0->DMA_CTRL = 0x3;
	SPI0->DMA_TH = 1 << 8;
	
	M0_DMA->CHx[5].CNDTR = 100;
	M0_DMA->CHx[5].CPAR  = (uint32_t)&SPI0->FIFO;
	M0_DMA->CHx[5].CMAR  = (uint32_t)&txbuf;
	M0_DMA->CHx[5].CCR   = 0x009E;	//spi tx
	
	M0_DMA->CHx[4].CNDTR = 100;
	M0_DMA->CHx[4].CPAR  = (uint32_t)&SPI0->FIFO;
	M0_DMA->CHx[4].CMAR  = (uint32_t)&rxbuf;
	M0_DMA->CHx[4].CCR   = 0x028E;	//spi rx
	
	M0_DMA->CHx[4].CCR   |= 1;
	M0_DMA->CHx[5].CCR   |= 1;
	
	Delay_ms(200);
	
	//MEMORY->CJENC.DIN CJENC.DOUT->MEMORY
	PeriCLK_Cmd(CJENC_PCLK | CJDEC_PCLK, ENABLE);
	
	M0_CJENC->SIGMA = sigma;
	M0_CJENC->KEY = userKey;
	M0_CJENC->CR = (0x1 << 2) | (0x1 << 3) | (0x1 << 4) | (0x1 << 5) | (0x1 << 6);
	M0_CJENC->CR |= 1;
	
	for(int i = 0; i < 5; i++)
	{
		txbuf32[i] = i;
	}
	
	M0_DMA->CHx[0].CCR   &= ~1;
	M0_DMA->CHx[0].CNDTR = 5;
	M0_DMA->CHx[0].CPAR  = (uint32_t)&M0_CJENC->DIN;
	M0_DMA->CHx[0].CMAR  = (uint32_t)&txbuf32;
	M0_DMA->CHx[0].CCR   = 0x0A9E;
	
	M0_DMA->CHx[1].CCR   &= ~1;
	M0_DMA->CHx[1].CNDTR = 5;
	M0_DMA->CHx[1].CPAR  = (uint32_t)&M0_CJENC->DOUT;
	M0_DMA->CHx[1].CMAR  = (uint32_t)&rxbuf32;
	M0_DMA->CHx[1].CCR   = 0x0A8E;
	
	M0_DMA->CHx[1].CCR   |= 1;
	M0_DMA->CHx[0].CCR   |= 1;
	
	Delay_ms(200);
	if(memcmp(encryptedValue, rxbuf32, 5 * 4))
	{
		printf("Error: CJENC\n");
	}
	
	//MEMORY->CJDEC.DIN CJDEC.DOUT->MEMORY
	M0_CJDEC->SIGMA = sigma;
	M0_CJDEC->KEY = userKey;
	M0_CJDEC->CR = (0x1 << 2) | (0x1 << 3) | (0x1 << 4) | (0x1 << 5) | (0x1 << 6);
	M0_CJDEC->CR |= 1;
	
	memcpy(txbuf32, encryptedValue, 5 * 4);
	
	M0_DMA->CHx[2].CCR   &= ~1;
	M0_DMA->CHx[2].CNDTR = 5;
	M0_DMA->CHx[2].CPAR  = (uint32_t)&M0_CJDEC->DIN;
	M0_DMA->CHx[2].CMAR  = (uint32_t)&txbuf32;
	M0_DMA->CHx[2].CCR   = 0x0A9E;
	
	M0_DMA->CHx[3].CCR   &= ~1;
	M0_DMA->CHx[3].CNDTR = 5;
	M0_DMA->CHx[3].CPAR  = (uint32_t)&M0_CJDEC->DOUT;
	M0_DMA->CHx[3].CMAR  = (uint32_t)&rxbuf32;
	M0_DMA->CHx[3].CCR   = 0x0A8E;
	
	M0_DMA->CHx[3].CCR   |= 1;
	M0_DMA->CHx[2].CCR   |= 1;
	
	Delay_ms(200);
	for(int i = 0; i < 5; i++)
	{
		if(rxbuf32[i] != i)
		{
			printf("Error: CJDEC\n");
		}
	}
	
	printf("++++++++++++++++++++DmaTest++++++++++++++++++++\n\n");
 	return ret;
}

RES_t CrcTest(void)
{
	RES_t ret = OK;
	//CRC7-MMC  CRC8  CRC16-IBM  CRC32-MPEG2
	const u32 crc_poly[]    = {0x09, 0x07, 0x8005, 0x04C11DB7};
	const u8 crc_polySize[] = {0x3,  0x2,  0x1,	   0x0};	//0:32bit 1:16bit 2:8bit 3:7bit
	const u8 crc_revIn[]    = {0x0,  0x0,  0x1,    0x0};	//0:no rev 1:byte rev 2:half word rev 3:word rev
	const u8 crc_revOut[]   = {0x0,  0x0,  0x1,    0x0};
	const u32 crc_Init[]    = {0x00, 0x00, 0x0000, 0xFFFFFFFF};
	const u8 crc_input[]    = {0x12, 0x34, 0x56, 0x78, 0xaa, 0xbb, 0xcc, 0xdd};
	const u32 crc_output[]  = {0x5E, 0xE6, 0x8E9D, 0x7C9FBAF3};
	printf("--------------------CrcTest--------------------\n");
	PeriCLK_Cmd(CRC_CLK, ENABLE);
	
	for(int i = 0; i < sizeof(crc_poly) / sizeof(crc_poly[0]); i++)
	{
		M0_CRC->INIT = crc_Init[i];
		M0_CRC->POL = crc_poly[i];
		M0_CRC->CR = 0x1 | (crc_polySize[i] << 3) | (crc_revIn[i] << 5) | (crc_revOut[i] << 7);
		for(int j = 0; j < sizeof(crc_input) / sizeof(crc_input[i]); j++)
		{
			M0_CRC->u8DR = crc_input[j];
		}
		if((M0_CRC->u32DR) != crc_output[i])
		{
			ret = Error;
			printf("Error: CRC %d: %x, expected:%x\n", i, M0_CRC->u32DR, crc_output[i]);
		}
	}
	PeriCLK_Cmd(CRC_CLK, DISABLE);
	printf("++++++++++++++++++++CrcTest++++++++++++++++++++\n\n");
	return ret;
}

RES_t CJEncDecTest(void)
{
	RES_t ret = OK;
	uint32_t userKey = 0x1A2B3C4D, value = 0x12345678, sigma = 0x3d5b8f9a;
	
	printf("--------------------CJEncDecTest--------------------\n");
	PeriCLK_Cmd(CJENC_PCLK | CJDEC_PCLK, ENABLE);
	
	M0_CJENC->SIGMA = sigma;
	M0_CJDEC->SIGMA = sigma;
	M0_CJENC->KEY = userKey;
	M0_CJDEC->KEY = userKey;
	M0_CJENC->CR = (0x1 << 4) | (0x1 << 5) | (0x1 << 6);
	M0_CJDEC->CR = (0x1 << 4) | (0x1 << 5) | (0x1 << 6);
	M0_CJENC->CR |= 1;
	M0_CJDEC->CR |= 1;
	
	M0_CJENC->DIN = value;
	while(M0_CJENC->ISR == 0);
	value = M0_CJENC->DOUT;
	if(value != 0x7881a8e7)
	{
		ret = Error;
		printf("Error: dout: %x, expected:%x\n", value, 0x7881a8e7);
	}
	
	M0_CJDEC->DIN = value;
	while(M0_CJDEC->ISR == 0);
	value = M0_CJDEC->DOUT;
	if(value != 0x12345678)
	{
		ret = Error;
		printf("Error: dout: %x, expected:%x\n", value, 0x12345678);
	}
	
	PeriCLK_Cmd(CJENC_PCLK | CJDEC_PCLK, DISABLE);
	printf("++++++++++++++++++++CJEncDecTest++++++++++++++++++++\n\n");
	return ret;
}

void RTC_IRQHandler(void)
{
    static int num = 0;
    RTC_DateTypedef date;
    if (RTC_GetIntStat())
    {
        RTC_GetCurrentTime(&date);
        printf("Now:%02x-%02x-%02x %02x:%02x:%02x\n", date.year, date.month, date.day,
               date.hour, date.minute, date.second);
        if (num++ == 5)
        {
            RTC_Cmd(DISABLE);
        }
        RTC_IntClr();
    }
}

RES_t RtcTest(void)
{
	RES_t ret = OK;

	printf("--------------------RtcTest--------------------\n");
	RTC_InitTypedef RTC_InitStructure;

	PeriCLK_Cmd(RTC_OSC32K_PCLK | RTC_HCLK, ENABLE);
	Peri_SoftReset(2);
    RTC_InitStructure.CLK_Sel = RTC_CLK_LSI;
    RTC_InitStructure.Div    = 40000;
    RTC_InitStructure.Year   = 0x21;
    RTC_InitStructure.Month  = 0x12;
    RTC_InitStructure.Day    = 0x13;
    RTC_InitStructure.Hour   = 0x12;
    RTC_InitStructure.Minute = 0x30;
    RTC_InitStructure.Second = 0x56;
    RTC_Init(&RTC_InitStructure); 
    RTC_IntInit(3, ENABLE);                               
    RTC_SetAlarmTime(0x14, 0x12, 0x31, 0x00, Day_ALM_Msk); 
	/*	RTC_IntMask();*/
    printf("start\n");
	RTC_Cmd(ENABLE);
    for (int i = 0; i < 1000; i++)
    {
        Delay_ms(10);
    }
    RTC_Cmd(DISABLE);
	printf("++++++++++++++++++++RtcTest++++++++++++++++++++\n\n");
	return ret;
}

RES_t IWdgTest(void)
{
	RES_t ret = OK;

	printf("--------------------IWdgTest--------------------\n");
	PeriCLK_Cmd(IWDG_OSC32K_PCLK | IWDG_PCLK, ENABLE);
	M0_IWDG->KR = 0x5555;	//IWDG寄存器访问
	M0_IWDG->PR = 0x5;	//128分频
	M0_IWDG->RLR = 4000;	//重载值向下计数
	while(M0_IWDG->SR != 0);
	M0_IWDG->KR = 0xCCCC;	//启动IWDG
	M0_IWDG->KR = 0xAAAA;	//reload
	PeriCLK_Cmd(IWDG_OSC32K_PCLK | IWDG_PCLK, DISABLE);
	printf("++++++++++++++++++++IWdgTest++++++++++++++++++++\n\n");
	return ret;
}

void WWDG_IRQHandler(void)
{
	M0_WWDG->CR = (0x1 << 7) | (0x60);
	M0_WWDG->SR = 0;
	printf("WWDG Int\n");
}

RES_t WWdgTest(void)
{
	RES_t ret = OK;

	printf("--------------------WWdgTest--------------------\n");
	PeriCLK_Cmd(WWDG_PCLK, ENABLE);
	M0_WWDG->SR = 0;
	M0_WWDG->CR = 0x60;	//计数器
	M0_WWDG->CR |= (0x1 << 7) | (0x60);	//复位使能
	M0_WWDG->CFR = 0x50 | (1 << 9) | (0x7 << 11);	//window, early wakeup int, 0x6=64分频
	NVIC_SetPriority(WWDG_IRQn, 3);
    NVIC_EnableIRQ(WWDG_IRQn);
	printf("++++++++++++++++++++WWdgTest++++++++++++++++++++\n\n");
	return ret;
}

RES_t I2CTest(void)
{
	RES_t ret = OK;
    I2CM_InitTypedef I2CM_InitStructure;
    GPIO_InitTypedef GPIO_InitStructure;
	
	printf("--------------------I2CTest--------------------\n");
    PeriCLK_Cmd(GPIO_PCLK, ENABLE);
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Drive = GPIO_Dr_High;
    GPIO_InitStructure.GPIO_Speed = GPIO_Sr_Fast;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    GPIO_AlternateFunction(GPIOB, GPIO_Pin_0 | GPIO_Pin_1, 2, GPIO_Digital);

    I2CM_InitStructure.CLK_Div_H = 0x10; /* H/L=2:1 about 400KHz */
    I2CM_InitStructure.CLK_Div_L = 0x24;
    I2CM_InitStructure.HOLD      = 5; /* SDA hold from SCL-LOW */
    I2CM_InitStructure.GCALL     = GCALL_DIS;
    I2CM_InitStructure.SBYTE     = SBYTE_DIS;
    I2CM_InitStructure.HS_MODE   = HSMODE_DIS;
    I2CM_InitStructure.STOP_MODE = SCL_L; /* 通过软件控制停止位 */
    I2CM_InitStructure.ADDR_MODE = ADDR_7bits;
    I2C_MasterInit(&I2CM_InitStructure);
    I2C_Cmd(ENABLE);

    /* Write Cmd */
    I2C_SetAddr(0x55); /* 7bit device_addr */
	I2C_WrByte(0x11);
	I2C_WrByte(0x22);
	I2C_WrByte(0x33);
	I2C_WrByte(0x44);
	PeriCLK_Cmd(I2C_PCLK, DISABLE);
	printf("++++++++++++++++++++I2CTest++++++++++++++++++++\n\n");
	return ret;
}

RES_t SpiTest(void)
{
	RES_t ret = OK;
    SPIM_InitTypedef SPIM_InitStructure;

	printf("--------------------SpiTest--------------------\n");
    PeriCLK_Cmd(GPIO_PCLK, ENABLE); 
    GPIO_AlternateFunction(GPIOB, GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5, 1,
                           GPIO_Digital);
    SPIM_InitStructure.CLK_Div   = 10; /* must be even. */
    SPIM_InitStructure.CPOL      = CPOL_H;
    SPIM_InitStructure.CPHA      = CPHA_2ndedge;
    SPIM_InitStructure.NSS_TOG   = NSS_TOG_until_Stop;
    SPIM_InitStructure.TMODE     = TMOD_TR;
    SPIM_InitStructure.DATA_SIZE = BIT_8;
    SPI_Master_Init(SPI0, &SPIM_InitStructure);
    SPI_Cmd(SPI0, ENABLE);

    SPI_FullDupData(SPI0, 0xFF);
    SPI_FullDupData(SPI0, 0xF2);
    SPI_FullDupData(SPI0, 0xAA);
	printf("++++++++++++++++++++SpiTest++++++++++++++++++++\n\n");
	return ret;
}

void FVT_IRQHandler(void)
{
	uint32_t intStatus = M0_FVT->ISR;
    if (intStatus & FVT_IT_FREQ_L)
    {
        printf("Freq low int\n");
        M0_FVT->ICR = FVT_IT_FREQ_L;
    }
    else if (intStatus & FVT_IT_FREQ_H)
    {
        printf("Freq high int\n");
        M0_FVT->ICR = FVT_IT_FREQ_H;
    }
    else if (intStatus & FVT_IT_VD_L)
    {
        printf("Vol low int\n");
		M0_FVT->ICR = FVT_IT_VD_L;
    }
    else if (intStatus & FVT_IT_VD_H)
    {
        printf("Vol high int\n");
		M0_FVT->ICR = FVT_IT_VD_H;
    }
    else if (intStatus & FVT_IT_TEMP_L)
    {
        printf("Temperature low int\n");
		M0_FVT->ICR = FVT_IT_TEMP_L;
    }
    else if (intStatus & FVT_IT_TEMP_H)
    {
        printf("Temperature high int\n");
		M0_FVT->ICR = FVT_IT_TEMP_H;
    }
	else if (intStatus & FVT_IT_GLITCH)
    {
        printf("glitch int\n");
		M0_FVT->ICR = FVT_IT_GLITCH;
    }
}

RES_t FVTTest(void)
{
	RES_t ret = OK;

	printf("--------------------FVTTest--------------------\n");
    PeriCLK_Cmd(FVT_PCLK, ENABLE);
	
    GPIO_AlternateFunction(GPIOB, GPIO_Pin_0, 4, GPIO_Digital); /* 频率检测PA1*/
	
    M0_FVT->FREQ.EN = 1;
    M0_FVT->FREQ_H  = 14408 * 21 / 48; 
    M0_FVT->FREQ_L  = 28818 * 21 / 48;
    M0_FVT->FREQ.IE = 1;
	
    FVT->ICR  = 0xff;
    FVT->ICLR = 1;
	
	Delay_ms(1);
	M0_FVT->ICR = 0xffff;
    NVIC_ClearPendingIRQ(FVT_IRQn);
    NVIC_SetPriority(FVT_IRQn, 0);
    NVIC_EnableIRQ(FVT_IRQn);
	
	printf("++++++++++++++++++++FVTTest++++++++++++++++++++\n\n");
	return ret;
}

/* tick给算法模块用 */
u32 tick = 0;
void SystickStart(void)
{
#if 1
    SysTick->LOAD = 0xFFFFFF;
    SysTick->VAL  = 0x00;
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_CLKSOURCE_Msk;
#endif
}

void SystickStop(void)
{
#if 1
    SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk;
    u32 count     = 0xFFFFFF - SysTick->VAL;
    count         += 0xFFFFFF * tick;
    u32 time      = count / 30;
    printf("\ntime: %d us", time);
    tick = 0;
#endif
}

void SysTick_Handler(void)
{
    tick++;
}


RES_t BootTest(void)
{
	RES_t ret = OK;
	
	uint32_t nvrSector[] = 
	{ 0x5a5aa5a5, 0x5555AAAA, 0xAAAA5555, 0x55AA55AA, 0xAA55AA55, 
	  0x3C3CC3C3, 0x004C3333, 0x04CC3333, 0x01C3C3C3, 0x0C3C3C3C,
	  0x5a5aa5a5, 0x0000001F, 0x005A5A5A, 0x0005AAAA, 0x00000000 };
	uint32_t expectedRegs[] = 
	{ 0x5555AAAA, 0xAAAA5555, 0x55AA55AA, 0xAA55AA55, 
	  0x3C3CC3C3, 0x004C0333, 0x04CC0133, 0x01C3C3C3, 0x0C3C3C3C,
	  0x0005AAAA, 0x005A5A5A, 0x0000001F };
	printf("--------------------BootTest--------------------\n");
	FLS_SectorErase(0x40200);
	FLS_ProgramPage(0x40200, 15, nvrSector);
	if(memcmp((uint32_t*)0x40200, nvrSector, sizeof(nvrSector)))
	{
		ret = Error;
		printf("Error: nvr sector\n");
	}
	if(memcmp(expectedRegs, (uint32_t*)&BOOT->JTAG_DISABLE, sizeof(expectedRegs)))
	{
		ret = Error;
		printf("Error: boot reg\n");
	}
	printf("++++++++++++++++++++BootTest++++++++++++++++++++\n\n");
	return ret;
}

RES_t RandomClockTest(void)
{
	printf("--------------------RandomClockTest--------------------\n");
	PeriCLK_Cmd(CLK_RANDOM_PCLK, ENABLE);
	M0_SYSCTRL->ENC_CTRL |= 1 << 7;
	M0_RANDOM_CLK->SEED = 0x5a5a5a5a;
	M0_RANDOM_CLK->MODE = 1;
	printf("1234567890\n");
	M0_SYSCTRL->ENC_CTRL &= ~(1 << 7);
	printf("++++++++++++++++++++RandomClockTest++++++++++++++++++++\n\n");
	return OK;
}

RES_t OneWireTest(void)
{
//    PeriCLK_Cmd(ONEWIRE_PCLK, ENABLE);
//    GPIO_AlternateFunction(GPIOA, GPIO_Pin_2, 1, GPIO_Digital);
//    ONEWIRE.CDR_O = (149 << 16) | 149;

//    ONEWIRE.POWER = 0x8a | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x8a)
//    {
//        ;
//    }

//    ONEWIRE.POWER = 0x88 | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x88)
//    {
//        ;
//    }
//    ONEWIRE.POWER = 0x89 | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x89)
//    {
//        ;
//    }
//    ONEWIRE.POWER = 0x89 | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x89)
//    {
//        ;
//    }
//    ONEWIRE.POWER = 0x88 | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x88)
//    {
//        ;
//    }

//    ONEWIRE.POWER = 0x1009b | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x9b)
//    {
//        ;
//    }
//    ONEWIRE.POWER = 0x1009f | ONEWIRE_PWR_OVD_MSK;
//    while (ONEWIRE.POWER == 0x9f)
//    {
//        ;
//    }
//    ONEWIRE.POWER = 0x8b;
//    ONEWIRE.POWER = 0x8f;
//	return OK;
}