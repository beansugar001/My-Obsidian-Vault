/**
 * @Description:CJW110оƬ��I2C�⺯��ͷ�ļ�
 *
 *
 ********************************************
 * �汾      ����      ����         �������
 * V1.0    2022-5-9    AE          �״η���
 *
 */
#ifndef __CJ32L01xx_I2C_H
#define __CJ32L01xx_I2C_H

#include "cj32l01xx.h"

/*  FS_MODE 100-400 KHz */
/*  HS_MODE 1MHz  */
#define TXFIFO_LEN 16
#define RXFIFO_LEN 16

#define I2C M0_I2C

typedef enum
{
    I2C_Slave,
    I2C_Master,
} I2CMS_t;

typedef enum
{
    GCALL_DIS, /* the first address is not the general call address */
    GCALL_EN,  /* the first address is the general call address */
} GCALL_t;

typedef enum
{
    SBYTE_DIS, /* Don't generate Start BYTE */
    SBYTE_EN,  /* Generate Start BYTE  for high speed MCODE */
} SBYTE_t;

typedef enum
{
    HSMODE_DIS, /* disable high speed mode */
    HSMODE_EN,  /* enable high speed mode */
} HSMODE_t;

typedef enum
{
    SCL_L,    /* If TX FIFO is empty, the I2CM holds SCL low */
    GEN_STOP, /* If TX FIFO is empty, the I2CM generates a STOP condition */
} STOP_t;

typedef enum
{
    ADDR_7bits,  /* 7bits address mode */
    ADDR_10bits, /* 10bits address mode */
} ADDR_Mode_t;

typedef enum
{
    I2C_WR, /* I2C master write */
    I2C_RD, /* I2C master read */
} I2C_RnW_t;

typedef enum
{
    I2C_FIFO_TX_EMPTY = 1,
    I2C_FIFO_TX_FULL = 1 << 1,
    I2C_FIFO_RX_EMPTY = 1 << 2,
    I2C_FIFO_RX_FULL = 1 << 3,
    I2C_FIFO_TX_NUM = 1 << 8,
    I2C_FIFO_RX_NUM = 1 << 16,
} I2C_FIFO_stat_t;

typedef enum
{
    I2CM_Work = 1,
    I2CM_Data = 2,
    I2CS_Work = 1 << 8,
} I2C_stat_t;

typedef enum
{
    I2C_INT_TX_Threshold = 1,
    I2C_INT_TX_Empty = 1 << 1,
    I2C_INT_TX_Full = 1 << 2,
    I2C_INT_TX_Rd_Err = 1 << 3,
    I2C_INT_TX_Wr_Err = 1 << 4,
    I2C_INT_RX_Threshold = 1 << 5,
    I2C_INT_RX_Empty = 1 << 6,
    I2C_INT_RX_Full = 1 << 7,
    I2C_INT_RX_Rd_Err = 1 << 8,
    I2C_INT_RX_Wr_Err = 1 << 9,
    I2C_INT_Stop = 1 << 12,
    I2C_INT_NACK = 1 << 13,
    I2C_INT_M_Lose_ARBI = 1 << 14, /* I2CM lose arbitration */
    I2C_INT_S_GCALL = 1 << 15,
    I2C_INT_A_Err = 1 << 16,
    I2C_INT_ALL = 0xFFFFF,
} I2C_INT_t;

typedef enum
{
    I2C_TH_0B, /*  Set the threshold to 0 bytes */
    I2C_TH_4B,
    I2C_TH_8B,
    I2C_TH_12B,
} I2C_TH_t;

typedef enum
{
    I2C_THMODE_Not_Larger, /* FIFO�еĴ������ֽ���<=��ֵʱ�����ж� */
    I2C_THMODE_Not_Less,
} I2C_THMODE_t;

typedef enum
{
    I2C_THMODE_RX = 1, /* Set receiving threshold or transmitting threshold */
    I2C_THMODE_TX,
    I2C_THMODE_RTX, /* both */
} I2C_THMODE_RTX_t;

typedef enum
{
    I2C_EN = 1,
    I2C_TX_FIFO = 4,
    I2C_RX_FIFO = 8,
} i2c_func_t;

typedef struct
{
    u32 CLK_Div_H : 24;
    u32 CLK_Div_L : 24;
    GCALL_t GCALL : 1; /* general call */
    SBYTE_t SBYTE : 1; /* for high speed MCODE */
    HSMODE_t HS_MODE : 1;
    STOP_t STOP_MODE : 1;
    ADDR_Mode_t ADDR_MODE : 1;
    u8 HOLD;
} I2CM_InitTypedef;

typedef struct
{
    u16 ADDR : 10;
    GCALL_t GCALL : 1;
    u8 HOLD;
} I2CS_InitTypedef;

typedef enum
{
    I2CM_READ,
    I2CM_RESTART
} I2CM_readctrl_t;

RES_t I2C_MasterInit(const I2CM_InitTypedef *const I2CM_InitStruct); /* I2C������ʼ�� */
RES_t I2C_SlaveInit(const I2CS_InitTypedef *const I2CS_InitStruct);  /* I2C�ӻ���ʼ�� */
void I2C_HSInit(I2CMS_t mode, u8 MCODE, u8 I2C_FM_Div);              /* I2C��������ģʽ��ʼ�� */
void I2C_HSDeInit(void);                                             /* I2C��������ģʽȥ��ʼ�� */
void I2C_Cmd(FunctionalState sw);                                    /* I2C���� */
u8 I2C_GetFIFOStat(I2C_FIFO_stat_t I2C_FIFO_stat);                   /* I2C��ȡFIFO״̬ */
u8 I2C_GetStat(I2C_stat_t I2C_stat);                                 /* I2C��ȡ����״̬ */
RES_t I2C_SetAddr(u16 addr);                                         /* I2C���õ�ַ */
void I2C_WrByte(u8 byte);                                            /* I2C����д1btye */
void I2C_WrData(const u8 *data, u8 len);                             /* I2C����дlen�������� */
u8 I2C_RdByte(void);                                                 /* I2C��1byte */
void I2C_RdData(u8 *data, u8 len);                                   /* I2C������len�������� */
void I2CM_RdCtrl(I2CM_readctrl_t mode, u8 len);                      /* I2C�������ƶ�ʱ�� */
void I2C_GenerateStop(void);                                          /* I2C��������STOP�źŵ�������SCL_L */

void I2C_IntInit(I2C_INT_t I2C_INT, u8 pri, FunctionalState sw);                       /* I2C�жϳ�ʼ�� */
void I2C_SetThreshold(I2C_THMODE_t TH_Mode, I2C_THMODE_RTX_t RTX, I2C_TH_t threshold); /* I2C����FIFO��ֵ */
void I2C_IntUnMask(I2C_INT_t I2C_INT);                                                 /* I2C�ж�ȥ���� */
void I2C_IntMask(I2C_INT_t I2C_INT);                                                   /* I2C�ж����� */
void I2C_IntClr(I2C_INT_t I2C_INT);                                                    /* I2C�жϱ�־��� */
u32 I2C_GetIntStat(I2C_INT_t I2C_INT);                                                 /* I2C��ȡ�ж�״̬ */
u32 I2C_GetRawIntStat(I2C_INT_t I2C_INT);                                              /* I2C��ȡԭʼ�ж�״̬ */

void I2C_Master_FS_Routine(void);
void I2C_Master_HS_Routine(void);
void I2C_Slave_FS_Routine(void);
void I2C_Slave_HS_Routine(void);
#endif
