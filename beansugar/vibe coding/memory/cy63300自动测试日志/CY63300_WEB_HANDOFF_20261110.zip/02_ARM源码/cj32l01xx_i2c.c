/**
 * @Description:CJW110оƬ��I2C�⺯��
 *
 *
 ********************************************
 * �汾      ����      ����         �������
 * V1.0    2022-5-9    AE          �״η���
 *
 */
#include "cj32l01xx_i2c.h"
#include "sys.h"
//int test[2][10] = {
//    {1,   2, 33, 444, 5,  6,  789789, 45646, 1321321, 51},
//    {153, 3, 21, 231, 23, 13, 51,     321,   23,      1 }
//};
// static u8 I2C_Recv_byte[64];
static u8 I2C_Send_byte[64];
// static u8 *p_recbuf = I2C_Recv_byte;
static u8 *p_Sendbuf;
static RES_t status;
// static u8 I2C_Send_byte[16];
/**
 * @brief ����FS����ģʽ��ʼ��
 * @param none
 * @return none
 */
void I2C_Master_FS_Routine(void) {
    I2CM_InitTypedef I2CM_InitStructure;
    GPIO_InitTypedef GPIO_InitStructure;
    // CLKs_Freq_t clks;

    PeriCLK_Cmd(GPIO_PCLK, ENABLE); /* ��GPIOʱ�� */
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_OD;
    GPIO_InitStructure.GPIO_Drive = GPIO_Dr_High;
    GPIO_InitStructure.GPIO_Speed = GPIO_Sr_Fast;
    GPIO_Init(GPIOA, &GPIO_InitStructure); /* GPIOA Pin0/1���ÿ�© */
    GPIO_AlternateFunction(GPIOA, GPIO_Pin_0 | GPIO_Pin_1, 2, GPIO_Digital);
    // Get_CLKs_Freq(&clks);/* ��ȡAPBʱ�Ӻ�����I2CƵ�� */
    I2CM_InitStructure.CLK_Div_H = 0x10; /* H/L=2:1 about 400KHz */
    I2CM_InitStructure.CLK_Div_L = 0x24;
    I2CM_InitStructure.HOLD      = 5; /* SDA hold from SCL-LOW */
    I2CM_InitStructure.GCALL     = GCALL_DIS;
    I2CM_InitStructure.SBYTE     = SBYTE_DIS;
    I2CM_InitStructure.HS_MODE   = HSMODE_DIS;
    I2CM_InitStructure.STOP_MODE = SCL_L; /* ͨ����������ֹͣλ */
    I2CM_InitStructure.ADDR_MODE = ADDR_10bits;
    I2C_MasterInit(&I2CM_InitStructure);

    I2C_SetThreshold(I2C_THMODE_Not_Less, I2C_THMODE_RX,
                     I2C_TH_4B); /* ����>=4bytes���ɶ�Ӧ��־�¼� */
    I2C_IntInit((I2C_INT_t)(I2C_INT_RX_Threshold | I2C_INT_RX_Full |
                            I2C_INT_NACK | I2C_INT_Stop),
                2, ENABLE);
    I2C_IntUnMask((I2C_INT_t)(I2C_INT_RX_Threshold | I2C_INT_RX_Full |
                              I2C_INT_NACK | I2C_INT_Stop));
    I2C_Cmd(ENABLE);

    /* Write Cmd */
    I2C_SetAddr(0x354); /* 7bit device_addr */
    /* I2C_SetAddr(0x3D6);10bit device_addr */
    //    do
    {
        status = OK; /* ���·���,״̬���� */
        I2C_WrByte(0x11);
        I2C_WrByte(0x22);
        I2C_WrByte(0x33);
        I2C_WrByte(0x44);
        // Delay_ms(1); /* wait stop end. */
        // I2C_GenerateStop();
        I2CM_RdCtrl(I2CM_RESTART, 1);
        I2CM_RdCtrl(I2CM_READ,
                    5); /* Master read NACK generate by FIFO downflow */
        I2C_GenerateStop();
    }
    //	while (status);
}

/**
 * @brief I2C HS��������
 * @param none
 * @return none
 */
void I2C_Master_HS_Routine(void) {
    I2CM_InitTypedef I2CM_InitStructure;

    PeriCLK_Cmd(GPIO_PCLK, ENABLE); /* ��GPIOʱ�� */
    GPIO_AlternateFunction(GPIOA, GPIO_Pin_0 | GPIO_Pin_1, 1, GPIO_Digital);
    I2CM_InitStructure.CLK_Div_H = 0x08;
    I2CM_InitStructure.CLK_Div_L = 0x10; /* Hs mode */
    I2CM_InitStructure.HOLD      = 2;
    I2CM_InitStructure.GCALL     = GCALL_EN;
    I2CM_InitStructure.SBYTE     = SBYTE_DIS; /* for high speed MCODE */
    I2CM_InitStructure.HS_MODE   = HSMODE_EN;
    I2CM_InitStructure.STOP_MODE = SCL_L;
    I2CM_InitStructure.ADDR_MODE = ADDR_7bits;
    I2C_MasterInit(&I2CM_InitStructure);
    I2C_HSInit(I2C_Master, 0x02, 5); /* MCODE & FM_DIV */

    I2C_SetThreshold(I2C_THMODE_Not_Less, I2C_THMODE_RX, I2C_TH_4B);
    I2C_IntInit((I2C_INT_t)(I2C_INT_RX_Threshold | I2C_INT_RX_Full |
                            I2C_INT_NACK | I2C_INT_Stop),
                2, ENABLE);
    I2C_IntUnMask((I2C_INT_t)(I2C_INT_RX_Threshold | I2C_INT_RX_Full |
                              I2C_INT_NACK | I2C_INT_Stop));
    I2C_Cmd(ENABLE);

    do {
        status = OK;       /* ���·���,״̬���� */
        I2C_SetAddr(0x54); /* device_addr 7bit+w/r */
        I2C_WrByte(0x11);
        I2C_WrByte(0x22);
        I2C_WrByte(0x33);
        I2C_WrByte(0x44);
        // Delay_ms(1); /* wait stop end. */
        // I2C_GenerateStop();
        I2CM_RdCtrl(I2CM_RESTART, 1);
        I2CM_RdCtrl(I2CM_READ,
                    5); // Master read NACK generate by FIFO downflow
        I2C_GenerateStop();
    } while (status);
}

/**
 * @brief
 * @param
 * @return
 */
void I2C_Slave_FS_Routine(void) {
    I2CS_InitTypedef I2CS_InitStructure;

    PeriCLK_Cmd(GPIO_PCLK, ENABLE); /* ��GPIOʱ�� */
    GPIOA->OSOD |= GPIO_Pin_0 | GPIO_Pin_1;
    GPIO_AlternateFunction(GPIOA, GPIO_Pin_0 | GPIO_Pin_1, 1, GPIO_Digital);
    I2CS_InitStructure.ADDR =
        0x92; /* 7bit or 10bit mode auto by I2C slaver first byte. */
    I2CS_InitStructure.GCALL = GCALL_EN;
    I2CS_InitStructure.HOLD  = 5;
    I2C_SlaveInit(&I2CS_InitStructure);

    //    I2C_SetThreshold(I2C_THMODE_Not_Less, I2C_THMODE_RX, I2C_TH_4B);
    //    I2C_IntInit((I2C_INT_t)(I2C_INT_RX_Full | I2C_INT_RX_Threshold |
    //    I2C_INT_NACK | I2C_INT_Stop), 2, ENABLE);
    //    I2C_IntUnMask((I2C_INT_t)(I2C_INT_RX_Full | I2C_INT_RX_Threshold |
    //    I2C_INT_NACK | I2C_INT_Stop));

    I2C_IntInit(I2C_INT_Stop | I2C_INT_S_GCALL, 2, ENABLE);
    I2C_IntUnMask(I2C_INT_Stop | I2C_INT_S_GCALL);
    I2C_Cmd(ENABLE);

    p_Sendbuf = I2C_Send_byte;

    I2C_Send_byte[0] = 0x55;
    I2C_Send_byte[1] = 0x66;
    I2C_Send_byte[2] = 0x77;
    I2C_Send_byte[3] = 0x88;
    I2C_WrData(p_Sendbuf, 4);
}

/**
 * @brief
 * @param
 * @return
 */
void I2C_Slave_HS_Routine(void) {
    I2CS_InitTypedef I2CS_InitStructure;
    int dataNum = 0;

    PeriCLK_Cmd(GPIO_PCLK, ENABLE); /* ��GPIOʱ�� */
    GPIO_AlternateFunction(GPIOA, GPIO_Pin_0 | GPIO_Pin_1, 1, GPIO_Digital);
    I2CS_InitStructure.ADDR =
        0x92; // 7bit or 10bit mode auto by IIC slaver first byte.
    I2CS_InitStructure.GCALL = GCALL_DIS;
    I2CS_InitStructure.HOLD  = 0;
    I2C_SlaveInit(&I2CS_InitStructure);
    I2C_HSInit(I2C_Slave, 0x0A, 0x00);

    //    I2C_SetThreshold(I2C_THMODE_Not_Less, I2C_THMODE_RX, I2C_TH_8B);
    //    I2C_IntInit((I2C_INT_t)(I2C_INT_RX_Full | I2C_INT_RX_Threshold |
    //    I2C_INT_NACK | I2C_INT_Stop), 2, ENABLE);
    //    I2C_IntUnMask((I2C_INT_t)(I2C_INT_RX_Full | I2C_INT_RX_Threshold |
    //    I2C_INT_NACK | I2C_INT_Stop));
    I2C_Cmd(ENABLE);
    p_Sendbuf        = I2C_Send_byte;
    I2C_Send_byte[0] = 0x55;
    I2C_Send_byte[1] = 0x66;
    I2C_Send_byte[2] = 0x77;
    I2C_Send_byte[3] = 0x88;
    I2C_WrData(p_Sendbuf, 4); // �ӻ���
    while ((M0_I2C->FIFO_SR & 0xF0000) >> 16 == 0)
        ;
    Delay_ms(200);
    dataNum = (M0_I2C->FIFO_SR & 0xF0000) >> 16;
    for (int i = 0; i < dataNum; i++) {
        printf("%02x ", M0_I2C->FIFO);
    }
    putchar('\n');
}

/**
 * @brief I2C����ģʽ��ʼ��
 * @param *I2CM_InitStruct: �ο�I2CM_InitTypedef
 * @return ��ʼ�����
 */
RES_t I2C_MasterInit(const I2CM_InitTypedef *const I2CM_InitStruct) {
    u32 I2CM_CtrlReg;

    PeriCLK_Cmd(I2C_PCLK, ENABLE);
    if ((I2CM_InitStruct->GCALL == GCALL_EN) &&
        (I2CM_InitStruct->ADDR_MODE == ADDR_10bits))
        return ErrorInvalidParameter;
    I2CM_CtrlReg = I2CM_InitStruct->GCALL << I2C_GCALL_Pos |
                   I2CM_InitStruct->SBYTE << I2C_SBYTE_Pos |
                   I2CM_InitStruct->HS_MODE << I2C_HS_MODE_Pos |
                   I2CM_InitStruct->STOP_MODE << I2C_STOP_Pos |
                   I2CM_InitStruct->ADDR_MODE;
    M0_I2C->CLK_DIV0 = I2CM_InitStruct->CLK_Div_H - 1;
    M0_I2C->CLK_DIV1 = I2CM_InitStruct->CLK_Div_L - 1;
    M0_I2C->MCTR     = I2CM_CtrlReg;
    M0_I2C->HOLD     = I2CM_InitStruct->HOLD;
    M0_I2C->MD_CTR   = I2C_RX_FIFO_EN_Msk | I2C_TX_FIFO_EN_Msk;
    M0_I2C->MODE     = I2C_Master;
    return OK;
}

/**
 * @brief �ӻ�ģʽ��ʼ��
 * @param *I2CS_InitStruct: I2CS_InitTypedef
 * @return ��ʼ�����
 */
RES_t I2C_SlaveInit(const I2CS_InitTypedef *const I2CS_InitStruct) {
    PeriCLK_Cmd(I2C_PCLK, ENABLE);
    // M0_I2C->ADDR = I2CS_InitStruct->ADDR;
    I2C_SetAddr(I2CS_InitStruct->ADDR);
    M0_I2C->HOLD   = I2CS_InitStruct->HOLD;
    M0_I2C->MD_CTR = I2C_RX_FIFO_EN_Msk | I2C_TX_FIFO_EN_Msk;
    WRITE_BIT(M0_I2C->SCTR, I2C_GCALL_MODE_Msk, !I2CS_InitStruct->GCALL);
    M0_I2C->MODE = I2C_Slave;
    return OK;
}

/**
 * @brief ����ģʽ����(Master/Slaver)
 * @param MCODE: ����������
 * @param I2C_FM_Div: ����MSCODE���ͷ�Ƶ
 * @return none
 */
void I2C_HSInit(I2CMS_t mode, u8 MCODE, u8 I2C_FM_Div) {
    M0_I2C->MCODE = MCODE; /* ʶ������л� */
    if (mode == I2C_Master) {
        M0_I2C->MCTR |= I2C_HS_MODE_Msk;
        M0_I2C->FS_DIV = I2C_FM_Div;
    }
}

/**
 * @brief ����ģʽ��λ
 * @param none
 * @return none
 */
void I2C_HSDeInit(void) {
    M0_I2C->MCTR &= ~I2C_HS_MODE_Msk;
    M0_I2C->MCODE  = 1U;
    M0_I2C->FS_DIV = 5U;
}

/**
 * @brief I2C���迪������
 * @param sw: �ο�FunctionalState
 * @return none
 */
void I2C_Cmd(FunctionalState sw) {
    if (sw)
        M0_I2C->MD_CTR |= I2C_EN_Msk;
    else
        M0_I2C->MD_CTR &= ~I2C_EN_Msk;
}

/**
 * @brief ��ȡTX_FIFO/RX_FIFO״̬
 * @param I2C_FIFO_stat: �ο�I2C_FIFO_stat_tѡ���ź�
 * @return ������Ӧ״̬
 */
u8 I2C_GetFIFOStat(I2C_FIFO_stat_t I2C_FIFO_stat) {
    if (I2C_FIFO_stat & I2C_FIFO_TX_NUM)
        return (M0_I2C->FIFO_SR & I2C_FIFOSTA_TX_NUM_Msk) >>
               I2C_FIFOSTA_TX_NUM_Pos;
    else if (I2C_FIFO_stat & I2C_FIFO_RX_NUM)
        return (M0_I2C->FIFO_SR & I2C_FIFOSTA_RX_NUM_Msk) >>
               I2C_FIFOSTA_RX_NUM_Pos;
    else
        return M0_I2C->FIFO_SR & I2C_FIFO_stat;
}

/**
 * @brief ��ȡ״̬��״̬
 * @param I2C_stat
 * @return ����I2C״̬��״̬
 */
u8 I2C_GetStat(I2C_stat_t I2C_stat) { return M0_I2C->SR & I2C_stat; }

/**
 * @brief ����I2C����������ַ
 * @param addr: 7/16bit ��ַ
 * @return ����I2C���õ�ַ�ɹ�״̬
 */
RES_t I2C_SetAddr(u16 addr) {
    if (M0_I2C->MCTR & I2C_ADDR_MODE_Msk) /* 10 bit mode 1-8'b1111_0XXN
                                                       2-8'bXXXX_XXXX  N:W/R */
        M0_I2C->ADDR = addr;
    else {
        if ((addr & I2C_ADDR_FUTURE_Msk) == I2C_ADDR_FUTURE_Msk ||
            (addr & I2C_ADDR_FUTURE_Msk) == 0x00)
            return ErrorInvalidParameter;
        M0_I2C->ADDR = addr;
    }
    return OK;
}

/**
 * @brief I2C�ֽ�����д��TX_FIFO
 * @param byte: д��FIFO����
 * @return none
 */
void I2C_WrByte(u8 byte) {
    while (M0_I2C->FIFO_SR & I2C_FIFO_TX_FULL)
        ;
    M0_I2C->FIFO = byte;
}

/**
 * @brief I2C��������@����
 * @param *data: ������
 * @param len: ���ݳ���
 * @return none
 */
void I2C_WrData(const u8 *data, u8 len) {
    while (len--) {
        while (M0_I2C->FIFO_SR & I2C_FIFO_TX_FULL)
            ;
        M0_I2C->FIFO = *data;
        data++;
    }
}

/**
 * @brief ͨ��CTRL����ReStart/Read dataͨ��TX_FIFO
 * @param mode: �ο�I2CM_readctrl_t
 * @param len: Read data����
 * @return none
 */
void I2CM_RdCtrl(I2CM_readctrl_t mode, u8 len) {
    if (mode == I2CM_RESTART) {
        while (M0_I2C->FIFO_SR & I2C_FIFO_TX_FULL)
            ;
        M0_I2C->FIFO = I2C_RESTART_Msk | I2C_RnW_CTRL_Msk;
    } else // I2CM_READ
    {
        while (len--) {
            while (M0_I2C->FIFO_SR & I2C_FIFO_TX_FULL)
                ;
            M0_I2C->FIFO = I2C_RnW_CTRL_Msk;
        }
    }
}

/**
 * @brief ��RX_FIFO byte
 * @param none
 * @return ����FIFO����
 */
u8 I2C_RdByte(void) {
    u8 byte;

    byte = M0_I2C->FIFO;
    return byte;
}

/**
 * @brief ���̶���������
 * @param *data: ���ݴ��ָ��
 * @param len: �����ݳ���
 * @return none
 */
void I2C_RdData(u8 *data, u8 len) {
    while (len--) {
        *data = M0_I2C->FIFO;
        data++;
    }
}

/**
 * @brief ����I2C STOP�źŵ���STOP_tʹ�õ͵�ƽ����ģʽ��
 * @param none
 * @return none
 */
void I2C_GenerateStop(void) {
    WRITE_BIT(M0_I2C->MCTR, I2C_STOP_Msk, GEN_STOP); /* send stop */
    //    while (!I2C_GetRawIntStat(I2C_INT_Stop))
    //        ;
    //    I2C_IntClr(I2C_INT_Stop);
    //    WRITE_BIT(M0_I2C->MCTR, I2C_STOP_Msk, SCL_L); /* stay low when tx_fifo
    //    empty */
}

/**
 * @brief I2C�ж�����
 * @param I2C_INT: �ο�I2C_INT_tѡ���ж��ź�
 * @param pri: �ж����ȼ�0..3
 * @param sw: �ο�FunctionalState
 * @return none
 */
void I2C_IntInit(I2C_INT_t I2C_INT, u8 pri, FunctionalState sw) {
    assert_param(IS_NVIC_PRI(pri));

    if (sw) {
        M0_I2C->IE |= I2C_INT;
        NVIC_SetPriority(I2C_IRQn, pri);
        NVIC_EnableIRQ(I2C_IRQn);
    } else {
        M0_I2C->IE &= ~I2C_INT;
        NVIC_DisableIRQ(I2C_IRQn);
    }
}

/**
 * @brief I2C FIFO��ֵ����
 * @param TH_Mode: �ο�I2C_THMODE_t
 * @param RTX: �ο�I2C_THMODE_RTX_t
 * @param threshold: �ο�I2C_TH_t
 * @return none
 */
void I2C_SetThreshold(I2C_THMODE_t TH_Mode, I2C_THMODE_RTX_t RTX,
                      I2C_TH_t threshold) {
    TH_Mode ? (M0_I2C->ICTR |= I2C_TH_MODE_Msk)
            : (M0_I2C->ICTR &= ~I2C_TH_MODE_Msk);
    if (RTX & I2C_THMODE_TX)
        M0_I2C->ICTR = (M0_I2C->ICTR & ~I2C_TX_FIFO_TH_Msk) | threshold;
    if (RTX & I2C_THMODE_RX)
        M0_I2C->ICTR = (M0_I2C->ICTR & ~I2C_RX_FIFO_TH_Msk) | threshold << 8;
}

/**
 * @brief I2C�ж��������
 * @param I2C_INT: �ο�I2C_INT_t
 * @return none
 */
void I2C_IntUnMask(I2C_INT_t I2C_INT) { M0_I2C->IUNMASK |= I2C_INT; }

/**
 * @brief I2C�ж�����
 * @param I2C_INT: �ο�I2C_INT_t
 * @return none
 */
void I2C_IntMask(I2C_INT_t I2C_INT) { M0_I2C->IUNMASK &= ~I2C_INT; }

/**
 * @brief I2C�ж�RAW���
 * @param I2C_INT: �ο�I2C_INT_t
 * @return none
 */
void I2C_IntClr(I2C_INT_t I2C_INT) { M0_I2C->ICR = I2C_INT; }

/**
 * @brief ��ȡI2C�жϱ�־�ź�
 * @param I2C_INT
 * @return ���ر��
 */
u32 I2C_GetIntStat(I2C_INT_t I2C_INT) { return M0_I2C->ISR & I2C_INT; }

/**
 * @brief ��ȡ��RAW����ź�
 * @param I2C_INT
 * @return ���ر��
 */
u32 I2C_GetRawIntStat(I2C_INT_t I2C_INT) { return M0_I2C->RISR & I2C_INT; }

/**
 * @brief I2C�жϴ�������
 * @param none
 * @return none
 */
// void I2C_IRQHandler(void)
//{
//    if ((I2C_GetIntStat(I2C_INT_RX_Threshold)))
//    {
// #ifdef TESTPIN
//        TEST_PIN2();
// #endif
//        I2C_RdData(p_recbuf, I2C_TH_4B * 4);
//        p_recbuf += I2C_TH_4B * 4;
//        I2C_IntClr(I2C_INT_RX_Threshold);
//    }
//    else if (I2C_GetIntStat(I2C_INT_RX_Full))
//    {
//        I2C_RdData(p_recbuf, RXFIFO_LEN);
//        p_recbuf += RXFIFO_LEN;
//        I2C_IntClr(I2C_INT_RX_Full);
//    }
//    else if (I2C_GetIntStat(I2C_INT_Stop)) /*  */
//    {
//        I2C_RdData(p_recbuf, I2C_GetFIFOStat(I2C_FIFO_RX_NUM));
//        I2C_IntClr(I2C_INT_Stop);
//        p_recbuf = I2C_Recv_byte;
//    }
//    else if (I2C_GetIntStat(I2C_INT_NACK))
//    {
//        if (M0_I2C->MODE & I2C_MS_MODE_Msk) /* I2C MASTER */
//        {
//            I2C_GenerateStop();
//            I2C_IntClr(I2C_INT_NACK);
//            status = Error;
//        }
//        else /* I2C Slaver */
//        {
//            I2C_IntClr(I2C_INT_NACK);
//            p_Sendbuf = I2C_Send_byte;
//        }
//    }
//}
