# Notes: ARM I²C 卡点对照

## 来源
- 用户提供：CY63300_项目记忆_问题与进展记录.docx，项目记忆 V1.0，整理日期 2026-11-09。
- 本摘要不是原始完整波形/日志或芯片官方规格。
- 当前 RISC-V 依据：reports_current/V113_CONFIG_ORDER_VS_FIFO_STALL_20261110.md、reports_current/V114_PROGBUF_AND_DPC_RESULT_20261110.md。

## ARM 记录中的问题
- Master 使用 STOP_MODE=SCL_L。
- 故障快照：SR=0x03（WORK=1、DATA=1），TX_NUM 已由 1 到 0，FIFO 最后为空。
- 软件先等 DATA 清零、后调用 GenerateStop；但该模式下 DATA 退出可能依赖软件先发 STOP，导致等待死锁/超时。
- 修正：记录 DATA 曾置位；等 TX_NUM=0 后立即 GenerateStop；之后等待 WORK=0。
- 记录称修正后 Master 成功，Slave RX_COUNT 增长并反复收到 A5/5A。

## 与当前 RISC-V 状态的区别
- V113A3/A5：CLKEN=0x21、RST=0、ADDR=0x3C、控制器相关配置读回基本成立；FIFO=0x104（TX_NUM=1），STATUS=0x1（WORK=1、DATA=0），RAW=0，Pad8/9 IDR 读高。
- 当前字节已进入 TX FIFO，但最近可用快照未显示其被消费；因此停在 ARM 记录 STOP 卡点之前。
- V114 的 PROGBUF/postexec 不可用，未执行 CPU-store 对照。DPC 写回曾导致 hart running。V114C 在 running 状态下停止，未读 I²C；当前 I²C 状态未知。

## 下一次测试判断矩阵
- DATA 曾置位 && TX_NUM=0 && WORK 仍为1：与 ARM STOP 卡点一致；仅此条件下测试“立即 STOP，再等 WORK 清零”。
- TX_NUM 保持1 && DATA 从未置位：仍是事务未进入/未推进；STOP 修正不适用。检查真实 START/SCL、ADDR 语义与启动时序。
- 示波器见 START/地址但 NACK：进入地址/从机应答分支，不能归因于 FIFO 消费或 STOP。
- 见完整时钟/ACK且 TX_NUM 清零，但 STOP 后 WORK 不清：定位 STOP 生成/时序。

## 风险和边界
- OLED 地址 0x3C 与 ARM 双芯片样例地址 0x50 不同；不能照搬地址和分频值。
- PAD8/PAD9、AF3 记录可作映射对照，但以当前板级连接和芯片文档为准。
- 下一阶段尚未执行；硬件实验需新阶段日志/marker和明确授权。禁止依靠最终暂停值推断瞬态，需记录 sticky seen_WORK/seen_DATA/seen_TX_EMPTY/NACK/STOP。

## V115A–V115F 实测更新（2026-11-10）
- 重插后新基线：IDCODE `0x1E200A6F`、DMSTATUS `0x00430382`、SBCS `0x20040404`；PERI_CLKEN=0、PERI_RST=0。时钟关闭时跳过 I2C 内部寄存器读取。
- V115B 只开 GPIOB/I2C 时钟，`PERI_CLKEN <- 0x21` 后读回 `0x21`。
- V115C 配 Pad8/9 释放式开漏 AF3：ODR/OSOD/DIR=`0xC`，AFR1=`0x6C0`，IDR=`0x2C`。
- V115D 按 ARM 次序在 ADDR=`0x3C` 后写 MODULE_CTRL=`0x0D`，读回 `0x0E`，I2C_EN bit0 未置位；停止在 FIFO 写入前。
- V115E 先写临时地址 `0x50`，再使能 I2C，最后写 OLED 地址 `0x3C`；读回 MODULE_CTRL=`0x0F` 且空闲。
- V115F 在此使能顺序下只写一次 TX_FIFO=`0x00`；TX_NUM 保持 1，WORK=1、DATA=0、RAW=0。STOP 写入 0 次。
- 因此：配置顺序差异有实物证据，但不是 FIFO 停滞的充分解释。仍无真实 START/SCL/SDA 波形证据；GPIO 输入高采样不等于线路波形。
- 完整报告与各阶段日志、marker、脚本归档于 `D:\Obsidian\notes\笔记\beansugar\vibe coding\memory\cy63300自动测试日志\reports_20261110_130200\V115_REPLUG_ARM_ORDER`。
