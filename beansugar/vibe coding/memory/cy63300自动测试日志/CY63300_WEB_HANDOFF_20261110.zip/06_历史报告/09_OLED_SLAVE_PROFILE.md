# 当前从机：4 针 SSD1306 OLED

记录日期：2026-11-05  
状态：用户报告该 OLED 当前已接入；**尚未发出 I²C START**。本文仅依据本地模块手册、模块原理图和 STM32 示例建立画像与分阶段测试方案。

## 1. 资料确认

| 资料 | 发现 | SHA-256 |
|---|---|---|
| 中景园《0.96寸 OLED 使用手册 V2.0》 | 4 针模块；SSD1306；128×64；SCL/D0、SDA/D1；模块 VCC 标称 3–5.5 V | `BD79D4DB9F421BD9B825281427B9662D93C3BA393F5FDA7819878826D62AA84A` |
| 4 针 B 版结构图 | 4-pin I²C 模块结构 | `E5CF451497BA605DD745D83C4CE87FC8125640B2EEDEB0F7D1806E802446C458` |
| 4 针 I²C 模块原理图 | 默认地址字节 `0x78`；D/C# 接 VCC 时为 `0x7A`；板上含上电复位和 4.7 kΩ 电阻网络 | `668638F56E89A252EB6B23DF9D6F3A310BE128FB89B228E46C38402B4AC1AAFF` |
| STM32 `Hardware/OLED.c` | GPIOB8/B9 开漏位模拟；发送 `0x78`、命令控制字 `0x00`、数据控制字 `0x40`；初始化及显示内容 | `93F0BE70BB5A76EC658E61A7490DB9FD7AB91FB14C44EF393B3BB0595AEC92B9` |

用户给出的目录内未发现 SSD1306 正式芯片数据手册；当前先以模块手册/原理图和配套示例为依据，不把示例当成芯片规范。

## 2. 地址与字节格式

- 模块原理图的 `0x78` 是在线路上发送的 **8-bit 地址字节**，最低位为写位 0。
- 对控制器的 7-bit 地址字段，应使用 `0x78 >> 1 = 0x3C`。若该模块 D/C# 硬件绑到高电平，地址字节为 `0x7A`，对应 7-bit 地址 `0x3D`。
- 默认先按 `0x3C` 准备，但发送前仍应确认当前模块版本/地址绑带。禁止对 0x3C/0x3D 做地址扫描。
- 每个 OLED I²C 写帧的载荷以控制字开头：`0x00` 表示后续为命令；`0x40` 表示后续为显示数据。STM32 示例每帧发送地址字节、控制字、命令或数据，并产生 STOP。

## 3. 电气接线准入

手册允许 VCC=3–5.5 V，但 CY63300 I/O 是 3.3 V 系统；模块原理图包含上拉/保护网络，不能仅凭“模块可接 5 V”推断 SDA/SCL 的高电平一定兼容。为避免把总线拉到 5 V，调试连接建议：

| OLED 4-pin 丝印 | 连接 |
|---|---|
| GND | CY63300 板 GND，共地 |
| VCC | 3.3 V |
| SCL | CY63300 Pad8 / PB2 / I²C SCL |
| SDA | CY63300 Pad9 / PB3 / I²C SDA |

首次 START 前，用户需核对模块丝印和四根线的实际对应关系；尤其不要根据照片方向猜引脚排列。还应确认 OLED 的 SDA/SCL 空闲电压没有超过目标 VDD_IO，并且两线空闲高。板端内部上拉读高不是外部电压测量的替代品。

## 4. STM32 示例审查

源文件 `D:\project\stm32\4-1oled\Hardware\OLED.c`：

- 第 8–28 行：STM32 PB8=SCL、PB9=SDA，开漏输出，空闲释放为高。
- 第 55–68 行：逐位发送一个字节，之后额外给一个时钟；代码注释明确写着“不处理应答信号”。因此它不能作为 ACK 成功的证明，也不能用其软件行为替代本次硬件 ACK 检查。
- 第 73–79 行：OLED 命令帧为 `START, 0x78, 0x00, command, STOP`。
- 第 87–93 行：显示数据帧为 `START, 0x78, 0x40, data, STOP`。
- 第 271–320 行：提供 SSD1306 上电初始化顺序，先 `0xAE` 关显示，设置时钟/复用/偏移/扫描/COM/对比度/预充电/VCOMH，开电荷泵，`0xAF` 开显示，最后清屏。
- `main.c` 调用 OLED_Init 后显示示例文本；它是 STM32 的 GPIO 位模拟 I²C 工程，不是 CY63300 的可直接烧录程序。

## 5. 改写后的实物验证路线

原 `07_SINGLE_READ_TEST_GATE.md` 中 MPU `WHO_AM_I` 读事务已不适用于当前外设。此 OLED 路径先做写事务；不做未知地址扫描，不猜读寄存器。

### OLED-A：单帧地址/ACK/STOP 检查

前置只读核验：本次会话确认目标与 DAPLink、CPU halted、SBA idle/error-free、`PERI_CLKEN[5]=1`、`PERI_RST[5]=0`、Pad8/9 AF3/开漏/释放、`MODULE_CTRL` FIFO 位已开且 `I2C_EN=0`、FIFO 空、I2C 主状态 idle、RAW 状态无遗留错误、两条线路静态高、OLED 3.3 V 供电且共地、接线符合本文件表格、7-bit 地址已核实。

条件满足后，设置已确认的 7-bit ADDR（默认候选 0x3C），按 ARM 主机驱动“设地址后再开 I2C_EN”的顺序使能控制器；只发送一帧：

```text
START → 0x3C + W → 0x00 (command control) → 0xAF (display ON) → STOP
```

`0xAF` 是无参数的显示开命令，不写 GDDRAM，也不清除图像数据；若屏之前处于关闭状态，可能会显示上电后未初始化的内容。因此 OLED-A 的通过标准是波形中的 START、地址 ACK、控制字 ACK、命令 ACK 和 STOP，以及控制器回 idle；单看寄存器/SBCS 成功不算总线通过。NACK、超时、总线被拉低、FIFO/状态异常时立即停止，不自动重发、不换地址、不加事务。

**注意：**CY63300 手册/ARM 资料未充分证明 `ADDR` 到线上地址字节、首 FIFO 字节如何触发 START 的流片实现细节；须由实际 SDA/SCL 波形确认，不应预先宣称会按预期工作。

### OLED-B：完整初始化与可见图样

仅当 OLED-A 捕获到全部 ACK/STOP 后再进入。根据 STM32 OLED_Init 次序逐条发配置命令（参数命令及参数必须成对），最后发 `0xAF`；随后设置显示地址并发送有限、可识别的数据图样，例如在页 0 写入 `0xFF`、页 1 写入 `0x00` 的交替竖条。每帧需通过状态/波形判定并有限等待；失败即停，不重试、不盲目清屏。记录每帧地址、控制字、数据、ACK/NACK、STOP、状态和照片/波形。

OLED-B 会改变 OLED 易失显示配置和 GDDRAM，但不写 CY63300 Flash/NVR；OLED 重新上电通常会丢失该显示状态。第一轮不要一开始就发送 STM32 示例中的 1024 字节清屏/整屏绘制数据，先用有限图样验证连续 FIFO/数据阶段。

## 6. 当前状态与未确认项

- **从机身份：**按提供资料，是 SSD1306 4-pin I²C OLED；模块具体实物版本尚未读取丝印/照片确认。
- **当前接线：**用户已确认接线正确且 OLED 本身可用，并核对了此前列出的 OLED GND→板 GND、VCC→3.3 V、SCL→Pad8、SDA→Pad9。
- **地址：**资料给默认 7-bit `0x3C`，绑带高时 `0x3D`；当前接入模块的实际绑带还需确认。
- **芯片侧最近历史状态：**V8.4C 日志显示 `PERI_CLKEN=0x21`、`PERI_RST=0`、`MODULE_CTRL=0x0E`、FIFO 空、`I2C_EN=0`。这是历史快照，下次执行前必须同会话重读。
- **总线：**V8.5 尝试后 TX FIFO 两字节未被消费，工作态未退出；仍没有可确认的 ACK/STOP 波形记录。当前非空闲状态详情见 [`10_V85_OLED_FIRST_FRAME_RESULT.md`](10_V85_OLED_FIRST_FRAME_RESULT.md)。

## 来源

- [OLED 使用手册 V2.0](D:\BaiduNetdiskDownload\STM32入门教程资料\模块资料\8-OLED显示屏\中景园电子0.96寸OLED使用文档新手必看V2.0.pdf)
- [4-pin 模块 I²C 原理图](D:\BaiduNetdiskDownload\STM32入门教程资料\模块资料\8-OLED显示屏\中景园电子0.96OLED显示屏原理图\中景园电子0.96OLED显示屏IIC接口原理图.pdf.pdf)
- [4-pin B 版结构图](D:\BaiduNetdiskDownload\STM32入门教程资料\模块资料\8-OLED显示屏\中景园电子0.96OLED显示屏原理图\0.96寸4针B版本结构图.pdf)
- STM32 示例：`D:\project\stm32\4-1oled\Hardware\OLED.c` 和 `D:\project\stm32\4-1oled\User\main.c`。
